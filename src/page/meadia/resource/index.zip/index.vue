<template>
    <!-- 创意列表 -->
    <el-container class="is-vertical creative-list">
        <el-main>
            <el-row class="native-list-content">
                <el-col :span="24">
                    <div class="creative-param">
                        <div class="creative-nav-row c-size clear">
                            <el-collapse>
                                <el-collapse-item name="1">
                                    <template slot="title" style="height:48px;">
                                                                                                                                                                                                                                                                                                                                                                    <span class="fold-iron"></span>
                                                                                                                                                                                                                                                                                                                                                                    <span class="hd left">选择媒体：</span>
                                                                                                                                                                                                                                                                                                                                                                        <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">全选</el-checkbox>
                                                                                                                                                                                                                                                                                                                                                                        <el-checkbox-group v-model="checkedSizes" @change="handleCheckedCitiesChange">
                                                                                                                                                                                                                                                                                                                                                                            <el-checkbox v-for="size in sizeData" :label="size" :key="size">{{size}}</el-checkbox>
                                                                                                                                                                                                                                                                                                                                                                        </el-checkbox-group>
</template>
                                </el-collapse-item>
                            </el-collapse>
                        </div>
                        <div class="creative-nav-row c-type clear">
                            <span class="hd align-right left">选择资源类型：</span>
                            <div class="bd">
                                <el-checkbox :indeterminate="isIndeterminateType" v-model="checkAllType" @change="handleCheckAllChangeType">全选</el-checkbox>
                                <el-checkbox-group v-model="checkedType" @change="handleCheckedTypeChange">
                                    <el-checkbox v-for="type in typeList" :label="type" :key="type">{{type}}</el-checkbox>
                                </el-checkbox-group>
                            </div>
                        </div>
                    </div>
                    <div class="native-list-bd">
                        <el-button type="click" class="open-clicked" @click="modifyConfig">批量配置</el-button>
                                <el-input class="el-search right" placeholder="请输入关键词" prefix-icon="el-icon-search" v-model="searchname" @change="getDataByName">
                                </el-input>
                            
                    <el-table :data="pageList.data" style="width: 100%" @selection-change="handleSelectionChange">
                        <el-table-column type="selection">
                        </el-table-column>
                        </el-table-column>
                        <el-table-column prop="theme" label="渠道名称">
<template slot-scope="scope">
     {{ scope.row.name }}
</template>
                        </el-table-column>
                        <el-table-column prop="size" label="广告位">
<template slot-scope="scope">
     {{ scope.row.ad_name }}
</template>
                        </el-table-column>
                        <el-table-column prop="family" label="媒体">
<template slot-scope="scope">
     {{ scope.row.media_name }}
</template>
                        </el-table-column>
                    </el-table>

                     <el-dialog title="制作原生创意" :visible.sync="dialogNatieFormVisible">
        <el-form ref="nativeform" :model="nativeform" >
            <el-form-item label="模版名称：" :label-width="formLabelWidth">
                <span class="module-name">{{currentItem.name}}</span>
            </el-form-item>
            <el-form-item label="图片：" :label-width="formLabelWidth">
                <!-- <el-input placeholder="请输入内容" v-model="input10" clearable>
                </el-input>
                <el-upload class="upload-wrap" ref="upload" action="https://jsonplaceholder.typicode.com/posts/" :auto-upload="false">
                    <el-button slot="trigger" size="small" type="confirm">上传</el-button>
                    <span class="tips-important"></span>
                </el-upload> -->
                  <input type="file" name="pic" accept="*" id="file" @change="upload"/>
            </el-form-item>
            <el-form-item label="标题：" :label-width="formLabelWidth" v-show="currentItem.main_info&&currentItem.main_info.title">
                <el-input v-model="nativeform.title"  placeholder="请输入标题" clearable></el-input>
                <span class="tips-important"></span>
            </el-form-item>
            <el-form-item label="描述：" :label-width="formLabelWidth" v-show="currentItem.main_info&&currentItem.main_info.desc">
                <el-input  v-model="nativeform.desc" placeholder="请输入描述" clearable></el-input>
                <span class="tips-important"></span>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
            <div class="is-confirm">
                <!-- <el-button type="confirm" @click="submitNativeForm">确认</el-button>
                <el-button type="cancel" @click="dialogNatieFormVisible = false">取消</el-button> -->
            </div>
        </div>
    </el-dialog>
                    
                    </div>
                    <div class="block">
                          <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" 
                    :current-page="pageList&&pageList.current_page" :page-sizes="[10, 20, 30, 40]" 
                    :page-size="pageList&&pageList.per_page"  layout="total, sizes, prev, pager, next, jumper" 
                    :total="pageList&&pageList.total">
                    </el-pagination>
                    </div>
                </el-col>
            </el-row>
        </el-main>
    </el-container>

</template>

<script>
    import {
        meadia
    } from "../../../service/index"
    import {
        mapState,
        mapActions,
        mapGetters
    } from "vuex";
    export default {
        data: function() {
            return {
                adList: [], //广告主
                adUser: '',
                pageList: [],
                pageSize: 10,
                searchname: "", //
                //创意尺寸
                checkAll: false,
                checkedSizes: [],
                sizeData: [], //创意尺寸
                isIndeterminate: false,
                //媒体类型
                checkAllType: false,
                checkedType: [],
                typeList: ["banner", "video", "native"], //类型集合 1banner 2video 3native
                isIndeterminateType: false,
                typeSourceDate: [],
                dialogFormVisible: false,
                nativeform: {
                    name: "",
                    img: "",
                    title: "",
                    desc: ""
                },
                currentId: "",
                dialogNatieFormVisible: false,
                formLabelWidth: "200",
                currentItem: ""
            }
        },
        mounted() {
            this.setBreadCrumb(this.$route.path.replace("/", ""));
            meadia.getPlatAll().then(res => {
                if (res.data.code == 0) {
                    this.typeSourceDate = res.data.data;
                    for (var j = 0; j < this.typeSourceDate.length; j++) {
                        this.sizeData.push(this.typeSourceDate[j].name);
                    }
                }
            });
            this.getList({
                page: 1,
                pagesize: 10
            });
        },
        methods: {
            ...mapActions([
                "setBreadCrumb"
            ]),
            //创意尺寸
            handleSizeChange(val) {
                this.pageSize = val;
                // creative.creativeListPage({
                //     page: 1,
                //     pagesize: this.pageSize,
                // });
                this.getList({
                    page: 1,
                    pagesize: this.pageSize
                });
            },
            handleCurrentChange(val) {
                // creative.creativeListPage({
                //     page: val,
                //     pagesize: this.pageSize,
                // });
                this.getList({
                    page: val,
                    pagesize: this.pageSize
                });
            },
            //创意尺寸
            handleCheckAllChange(val) {
                this.checkedSizes = val ? this.sizeData : [];
                this.isIndeterminate = false;
                this.getList({
                    plat_id: this.getIdsByName(this.checkedSizes)
                });
            },
            handleCheckedCitiesChange(value) {
                let checkedCount = value.length;
                this.checkAll = checkedCount === this.sizeData.length;
                this.isIndeterminate =
                    checkedCount > 0 && checkedCount < this.sizeData.length;
                this.getList({
                    plat_id: this.getIdsByName(value)
                });
            },
            //创意类型
            handleCheckAllChangeType(val) {
                this.checkedType = val ? this.typeList : [];
                this.isIndeterminateType = false;
                this.getList({
                    sources_type: this.gitTypeIds(this.checkedType)
                });
            },
            handleCheckedTypeChange(value) {
                let checkedCount = value.length;
                this.checkAllType = checkedCount === this.typeList.length;
                this.isIndeterminateType =
                    checkedCount > 0 && checkedCount < this.typeList.length;
                this.getList({
                    sources_type: this.gitTypeIds(value)
                });
            },
            getIdsByName(val) {
                console.log(val);
                console.log(this.typeSourceDate);
                let result = [];
                for (var j = 0; j < val.length; j++) {
                    for (var k = 0; k < this.typeSourceDate.length; k++) {
                        if (val[j] == this.typeSourceDate[k].name) {
                            result.push(this.typeSourceDate[k].id);
                        }
                    }
                }
                return result;
            },
            getList(data) {
                meadia.getResourceList(data).then(res => {
                    let data = res.data.data.data;
                    this.pageList = res.data.data;
                });
            },
            getStateValue(value) {
                let sourceData = [{
                    key: "开启",
                    value: "1"
                }, {
                    key: "关闭",
                    value: "2"
                }]; //状态集合 1开启 2 关闭
                let result = [];
                for (var j = 0; j < value.length; j++) {
                    for (var k = 0; j < sourceData.length; k++) {
                        if (!sourceData[k]) {
                            break;
                        }
                        if (value[j] == sourceData[k].key) {
                            result.push(sourceData[k].value);
                        }
                    }
                }
                return result;
            },
            gitTypeIds(value) {
                let sourceData = [{
                    key: "banner",
                    value: "1"
                }, {
                    key: "video",
                    value: "2"
                }, {
                    key: "native",
                    value: "3"
                }]; //类型集合 1banner 2video 3native
                let result = [];
                for (var j = 0; j < value.length; j++) {
                    for (var k = 0; j < sourceData.length; k++) {
                        if (!sourceData[k]) {
                            break;
                        }
                        if (value[j] == sourceData[k].key) {
                            result.push(sourceData[k].value);
                        }
                    }
                }
                return result;
            },
            changUser() {
                console.log(this.adUser);
            },
            getDataByName() {
                this.getList({
                    page: 1,
                    pagesize: 10,
                    seachname: this.searchname
                });
            },
            getIds(value) {
                let result = [];
                for (var j = 0; j < value.length; j++) {
                    result.push(value[j].id);
                }
                return result;
            },
            handleSelectionChange(val) {
                this.multipleSelection = val;
            },
            preTempalte(val) {
                // console.log(val);
                // return;
                this.$router.push({
                    path: "/pretemplate/" + val
                    // path: "/pretemplate"
                });
            },
            addNative(val) {},
            clearform() {
                this.nativeform = {
                    name: "",
                    img: "",
                    title: "",
                    desc: ""
                }
            },
            upload(event) {
                this.nativeform.img = this.$el.querySelector("#file").files[0];
            },
            modifyConfig() {
            }
        }
    }
</script>

<style lang="scss">
    @import '../../../style/mixin'; // 创意列表-共用样式
    .creative-list {
        .el-main {
            background-color: #fbfbfb;
            .template-hd,
            .creative-param,
            .native-list-bd,
            .creative-btn-control {
                background-color: #fff;
            }
        }
        .choose-ad {
            font-size: 14px;
            color: #515974;
            margin-right: 5px;
        }
        .creative-nav-row {
            padding: 15px 0;
            position: relative;
            &:first-child {
                padding: 0;
            }
        } // fold icon
        .fold-iron {
            background-color: #6cabff;
            position: absolute;
            top: 10px;
            right: 30px;
            height: 28px;
            width: 39px;
            @include borderRadius(5px);
        }
        .el-checkbox {
            float: left;
            margin-right: 21px;
        }
        .creative-btn-row {
            position: relative;
            padding: 10px 0;
        } // search input item
        .search-input {
            position: absolute;
            width: 182px;
            right: 0px;
            top: 0px;
        }
        .theme-pic {
            width: 60px;
            height: 60px;
        }
        .template-hd {
            padding: 17px 0 18px 30px;
            border-bottom-width: 1px;
        }
        .el-checkbox__label {
            color: #515974;
        }
        .el-checkbox+.el-checkbox {
            margin-left: 0;
        }
        .el-checkbox__input.is-checked+.el-checkbox__label {
            color: #7f8599;
        } // row
        .creative-param {
            padding: 9px 0 10px 30px;
            border-bottom: 2px solid #e1e7f0;
            span {
                font-size: 12px;
                line-height: 20px;
            }
            .hd {
                margin-right: 6px;
            }
            .align-right {
                margin-right: 30px;
            }
            .el-checkbox-group {
                padding-left: 78px;
            }
            .el-collapse-item__arrow {
                float: none;
                position: absolute;
                top: 1px;
                right: 35px;
                z-index: 20;
                color: #ffffff;
            }
        } // table style
        .el-table_1_column_1 .cell {
            padding-left: 30px;
        }
        .el-collapse-item__header {
            height: 52px;
            line-height: 52px;
            padding-right: 70px;
            overflow: hidden;
            border-bottom: 0 none;
            .hd {
                line-height: 52px;
            }
        }
        .el-collapse {
            border: 0 none;
        }
        .el-collapse-item__wrap {
            border-bottom: none;
        }
        .el-collapse-item__header.is-active {
            height: 104px;
            -webkit-transition: .3s height ease-in-out, .3s padding-top ease-in-out, .3s padding-bottom ease-in-out;
            transition: .3s height ease-in-out, .3s padding-top ease-in-out, .3s padding-bottom ease-in-out
        }
        .el-collapse-item__content {
            padding-bottom: 0;
        }
    } // 上传native素材
    .native-list-content {
        .mould-name {
            color: #5198f7;
            padding: 0!important;
            span {
                color: #5198f7;
            }
        }
        .native-list-bd {
            margin-top: 20px;
            .el-search {
                padding: 20px 20px 20px 0;
                width: 240px;
            }
            .el-input--prefix .el-input__inner {
                padding-left: 20px!important;
            }
            .el-input__prefix {
                left: 78% !important;
            }
        } // pop layer start
        .el-dialog__header {
            border-bottom: 1px solid #e1e7f0;
            padding: 15px 0 16px 30px;
        }
        .el-dialog__title {
            font-size: 16px;
            font-weight: bold;
        }
        .el-dialog__headerbtn {
            display: none;
        }
        .el-form-item__label {
            text-align: left;
            font-size: 14px;
            color: #515974;
            padding-right: 0;
        }
        .el-dialog__body {
            padding: 6px 0 0 30px;
        }
        .el-dialog__footer {
            padding: 0 0 30px 0;
        } // pop layer end
        .el-input {
            width: 41.5%;
        }
        .upload-wrap {
            display: inline-block;
        }
        .el-input {
            margin-right: 6px;
        }
        .el-form-item {
            margin-bottom: 12px;
            &:nth-child(2) {
                .tips-important {
                    margin-left: 11px;
                }
            }
        }
        .module-name {
            font-size: 12px;
            color: #b1b2c4;
        }
        .is-confirm {
            padding: 20px 0 0 30px;
            background-color: #fff;
            text-align: left;
        }
        .tips-important {
            display: inline-block;
            @include svgbg("../../../style/image/creative/tips-important.svg");
            height: 24px;
            width: 24px;
            vertical-align: -7px;
        }
        .see-iron {
            display: inline-block;
            @include svgbg("../../../style/image/creative/see-iron.svg");
            height: 19px;
            width: 25px;
            margin-left: 16px;
            vertical-align: 23px;
        }
    }
</style>